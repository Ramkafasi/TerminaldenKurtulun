import os
os.system("pkexec python3 /usr/local/bin/TerminaldenKurtulun/TerminaldenKurtulun.py")